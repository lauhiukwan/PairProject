import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


public class LoadFile {
    public static ArrayList<String> Dir(File dirFile) throws Exception {
        ArrayList<String> dirStrArr = new ArrayList<String>();
        if (dirFile.exists()) {
            File files[] = dirFile.listFiles();
            for (File file : files) {
                if (dirFile.getPath().endsWith(File.separator)) {
                    dirStrArr.add(dirFile.getPath() + file.getName());
                } else {
                    dirStrArr.add(dirFile.getPath() + File.separator
                            + file.getName());
                }
            }
        }
        return dirStrArr;
    }

    public static Set<String> DiviceKey(String s) {
        Set<String> strings = new HashSet<String>();
        String[] s1 = s.split("\",\"");//分割成数组
        s1[0] = s1[0].substring(2);
        s1[s1.length - 1] = s1[s1.length - 1].substring(0, s1[s1.length - 1].length() - 2);//处理首尾数据
        for (int i = 0; i < s1.length; i++) {
            strings.add(s1[i]);
        }
        return strings;
    }
    public static String toMouth(String s)
    {
        String m="01";
        if (s.toLowerCase().equals("jan.") || s.toLowerCase().equals("january"))
            m = "01";
        if (s.toLowerCase().equals("feb.") || s.toLowerCase().equals("february"))
            m = "02";
        if (s.toLowerCase().equals("mar.") || s.toLowerCase().equals("march"))
            m = "03";
        if (s.toLowerCase().equals("apr.") || s.toLowerCase().equals("april"))
            m = "04";
        if (s.toLowerCase().equals("may") || s.toLowerCase().equals("may"))
            m = "05";
        if (s.toLowerCase().equals("jun.") || s.toLowerCase().equals("june"))
            m = "06";
        if (s.toLowerCase().equals("jul.") || s.toLowerCase().equals("july"))
            m = "07";
        if (s.toLowerCase().equals("aug.") || s.toLowerCase().equals("august"))
            m = "08";
        if (s.toLowerCase().equals("sep.") || s.toLowerCase().equals("september"))
            m = "09";
        if (s.toLowerCase().equals("oct.") || s.toLowerCase().equals("october"))
            m = "10";
        if (s.toLowerCase().equals("nov.") || s.toLowerCase().equals("november"))
            m = "11";
        if (s.toLowerCase().equals("dec.") || s.toLowerCase().equals("december"))
            m = "12";
        return m;
    }

    public static String toDate(String s) throws ParseException {
        String[] s11 = s.split("\",\"");//分割成数组
        s = s11[0].substring(2, s11[0].length());
        String s1 = "";
        String[] ss = s.split(" ");
        String m = "";
        String y = "";
        String d = "";
        String[] ss2 = ss[0].split("-");
        d = ss2[0];
        if (d.length() == 1)
            d = "0" + d;
        m = "01";
        m=toMouth(ss[1]);
        y = ss[ss.length - 1];
        s1 = y + "-" + m + "-" + d;
//        DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
//        Date startDate = df.parse(s1);
        return s1;
    }
    public static String toDate2(String s){
            String[] ss = s.split(" ");
            return ss[2] + "-" + toMouth(ss[1]) + "-" + ss[0];
    }
    public static void main(String[] args) throws Exception {
        DB db = new DB();
        File file = new File("C:\\Users\\ppzy\\Desktop\\ICCV（2001年至2019年，3196篇）");
        File file1 = new File("C:\\Users\\ppzy\\Desktop\\CVPR（2000年至2020年，6916篇");
        File file2 = new File("C:\\Users\\ppzy\\Desktop\\ECCV（2016至2020，3033份）");
        List<String> lis = LoadFile.Dir(file1);
        List<String> lis2 = LoadFile.Dir(file);
        List<String> lis3 = LoadFile.Dir(file2);
        db.deletekey();
        db.deletepaper();
        for (int j = 0; j < lis3.size(); j++) {
            System.out.println("1"+j);
            File temp = new File((String) lis3.get(j));
            BufferedReader br = new BufferedReader(new FileReader(temp));
            String s = "";
            String temps;
            while ((temps = br.readLine()) != null) {
                s += temps;
            }
            JSONObject dataJson = new JSONObject();
            try {
                dataJson = JSONObject.fromObject(s);// 创建一个包含原始json串的json对象
            } catch (net.sf.json.JSONException e) {
                //file.delete();
                System.out.println("失败");
                continue;
            }
            String title = dataJson.getString("论文名称");
            String year = dataJson.getString("发布时间");
            String paperabstract = "none";
            if (dataJson.containsKey("摘要"))
                paperabstract = dataJson.getString("摘要");
            String url = dataJson.getString("原文链接");
            try {
                year = toDate2(year);
            } catch (java.lang.ArrayIndexOutOfBoundsException e) {
                temp.delete();
                continue;
            }
            //更改格式
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            //String year = format.format(date);date转字符串
            Date date = format.parse(year);//字符串转date
            paperabstract = paperabstract.replace("\'", "\'\'");
            try {
                db.newpaper(j + 1, title, "ECCV", url, paperabstract, year);
            } catch (java.sql.SQLException e) {
                //file.delete();
                continue;
            }
            JSONArray features = new JSONArray();
            try {
                features = dataJson.getJSONArray("关键词");
            } catch (net.sf.json.JSONException e) {
                //temp.delete();
                continue;
            }
            // 找到features的json数组
            Set<String> stringSet = new HashSet<String>();
            for (int i = 0; i < features.size(); i++) {
                String name = features.getString(i);// 读取properties对象里的name字段值
                //转成set对象
                stringSet.add(name);
            }
            for (String s3 : stringSet) {
                db.addkeyword(j+1,s3);
            }
        }
        for (int j = 0; j < lis2.size(); j++) {
            System.out.println("2"+j);
            File temp = new File((String) lis2.get(j));
            BufferedReader br = new BufferedReader(new FileReader(temp));
            String s;
            while ((s = br.readLine()) != null) {
                JSONObject dataJson = new JSONObject();
                try {
                    dataJson = JSONObject.fromObject(s);// 创建一个包含原始json串的json对象
                } catch (net.sf.json.JSONException e) {
                    file.delete();
                    continue;
                }
                String title = dataJson.getString("title");
                title = title.replace("\'", "\'\'");
                String year = dataJson.getString("conferenceDate");
                String paperabstract = "none";
                if (dataJson.containsKey("abstract"))
                    paperabstract = dataJson.getString("abstract");
                String url = dataJson.getString("doiLink");
                year = toDate(year);//更改格式
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                //String year = format.format(date);date转字符串
                Date date = format.parse(year);//字符串转date
                paperabstract = paperabstract.replace("\'", "\'\'");
                try {
                    db.newpaper(j +lis3.size()+ 1, title, "ICCV", url, paperabstract, year);
                } catch (java.sql.SQLException e) {
                    file.delete();
                    continue;
                }
                JSONArray features = new JSONArray();
                try {
                    features = dataJson.getJSONArray("keywords");
                } catch (net.sf.json.JSONException e) {
                    temp.delete();
                    continue;
                }
                // 找到features的json数组
                Set<String> stringSet=new HashSet<String>();
                for (int i = 0; i < features.size(); i++) {
                    JSONObject info = features.getJSONObject(i);
                    String type = info.getString("type");
                    String name = info.getString("kwd");// 读取properties对象里的name字段值
                    Set<String> stringSettemp= DiviceKey(name);//转成set对象
                    stringSet.addAll(stringSettemp);
                }
                for (String s3 : stringSet) {
                    s3=s3.replace("\'", "\'\'");
                    db.addkeyword(j +lis3.size()+ 1,s3);
                }
            }
        }
        for (int j = 0; j < lis.size(); j++) {
            System.out.println("3"+j);
            File temp = new File((String) lis.get(j));
            BufferedReader br = new BufferedReader(new FileReader(temp));
            String s;
            while ((s = br.readLine()) != null) {
                JSONObject dataJson = new JSONObject();
                try {
                    dataJson = JSONObject.fromObject(s);// 创建一个包含原始json串的json对象
                } catch (net.sf.json.JSONException e) {
                    file.delete();
                    continue;
                }
                String title = dataJson.getString("title");
                title = title.replace("\'", "\'\'");
                String year = dataJson.getString("conferenceDate");
                String paperabstract = "none";
                if (dataJson.containsKey("abstract"))
                    paperabstract = dataJson.getString("abstract");
                String url = dataJson.getString("doiLink");
                year = toDate(year);//更改格式
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                //String year = format.format(date);date转字符串
                Date date = format.parse(year);//字符串转date
                paperabstract = paperabstract.replace("\'", "\'\'");
                try {
                    db.newpaper(j +lis2.size()+lis3.size()+ 1, title, "PVPR", url, paperabstract, year);
                } catch (java.sql.SQLException e) {
                    file.delete();
                    continue;
                }
                JSONArray features = new JSONArray();
                try {
                    features = dataJson.getJSONArray("keywords");
                } catch (net.sf.json.JSONException e) {
                    temp.delete();
                    continue;
                }
                // 找到features的json数组
                Set<String> stringSet=new HashSet<String>();
                for (int i = 0; i < features.size(); i++) {
                    JSONObject info = features.getJSONObject(i);
                    String type = info.getString("type");
                    String name = info.getString("kwd");// 读取properties对象里的name字段值
                    Set<String> stringSettemp= DiviceKey(name);//转成set对象
                    stringSet.addAll(stringSettemp);
                }
                for (String s3 : stringSet) {
                    s3=s3.replace("\'", "\'\'");
                    db.addkeyword(j +lis2.size()+lis3.size()+ 1,s3);
                }
            }
        }
    }
}
