import java.sql.*;
import java.text.ParseException;

public class DB {

        String driver="com.mysql.cj.jdbc.Driver";
        String user="root";
        String password="";
        String url="jdbc:mysql://localhost:3306/web_paper?userSSL=true&useUnicode=true&serverTimezone=GMT&useSSL=false";
        Statement statement;
        ResultSet resultSet;
        String sql;
        private Connection connection;
        public DB() throws SQLException, ClassNotFoundException {
            Class.forName(driver);
            connection = DriverManager.getConnection(url, user, password);
            System.out.println("连接成功？？");
            statement = connection.createStatement();
        }
    public void newpaper(int id, String title, String meeting, String url, String paperabstract, String date) throws SQLException {
        sql="insert into paper (id,title,meeting,url,paperabstract,date) values ('"+id+"','"+title+"','"+meeting+"','"+url+"','"+paperabstract+"','"+date+"')";
        statement.execute(sql);
    }//添加一篇论文
    public void deletepaper() throws SQLException {
        sql="delete from paper";
        statement.execute(sql);
    }//
    public void deletepaper2() throws SQLException {
        sql="delete from paper where id>3185";
        statement.execute(sql);
    }//
    public void addkeyword(int id,String key) throws SQLException {
        sql="insert into papertokeyword (paper_id,keyword) values ('"+id+"','"+key+"')";
        statement.execute(sql);
    }
    public void deletekey() throws SQLException {
        sql="delete from papertokeyword";
        statement.execute(sql);
    }//
}
