document.writeln("<!DOCTYPE html>");
document.writeln("<html lang=\"en\">");
document.writeln("<head>")
document.writeln(" <meta charset=\"UTF-8\">")
document.writeln("<link rel=\"stylesheet\" type=\"text/css\" href=\"../static/css/navbar.css\">");
document.writeln("<title>Title</title>");
document.writeln("</head>");
document.writeln("<body>");
document.writeln("<div>");
document.writeln("<nav>");
document.writeln("<li><a href=\"index.html\">快爬</a></li>");
document.writeln("<li><a href=\"test.html\">论文列表</a></li>");
document.writeln("<li><a href=\"\">论文操作</a></li>");
document.writeln("<li><a href=\"\">热门领域</a></li>");
document.writeln("<li class=\"right\"><a href=\"\">关于我们</a></li>");
document.writeln("<li class=\"right\"><a href=\"login.html\">登录</a></li>");
document.writeln("</nav>");
document.writeln("</div>");
document.writeln("</body>");
document.writeln("</html>");